¤ Cara Menggunakan Fitur Custom Icon di Delta WhatsApp ¤

• Sediakan bahan icon yang mau diganti (disarankan size 48x48 sesuai size icon aslinya)

• Aktifkan custom icon lokasi di ekstra setting > home > custom icon

• Lalu cek di file manager bawaan hp lokasinya di memori internal folder Delta/WhatsApp/.icons

jika file .icons tidak muncul aktifkan terlebih dahulu file yang tersembunyi (hidden file) di settingan file manager bawaan hp 

• Replace/timpa icon yang mau diganti (samakan terlebih dahulu nama file iconnya dengan yang ada di .icons)

• Kembali ke tampilan depan WhatsApp lalu Restart WhatsApp (klik photo profil pojok kanan atas pilih restart whatsapp)
dan taraa...icon berubah secara otomatis

Semoga membantu dan bermanfaat.





Channel Telegaram WhatsApp Mod Themes
t.me/amakzone
@amakzone